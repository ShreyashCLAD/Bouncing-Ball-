let scene, camera;
let track_geometry, track_material;
let track_array = [];
let trackhor_geometry, trackhor_material;
let trackhor_array = [];
let star_mash1, star_mash2;
let collision;
let ball;
let Acylinder = [];
let hurdle_cylinder;
let collide_value = true;
let hurdle_geometry, hurdle_material;
let hurdle_array = [];
const container = document.getElementById('container');
let jump = true;
let score = 0;
let loader;
let bouncespeed = 0;
let bspeed = 1;
let p = 0;
let xi = 1;
let i = 0;
let speed = 0.4;
let speedVector;
let modal;
let final_score;
loader = new THREE.TextureLoader();

document.getElementById("player_name").innerHTML = sessionStorage.getItem("playername1");



// BACKGROUND SOUND



function initComplete() {

    domManipulate();
    createScene();
    createCamera();
    setLight();
    addBackground();
    createBall();
    createTrack_hurdles();
    createAudio();


    createStar();
}


function domManipulate() {
    modal = document.getElementById("myModal");
    final_score = document.getElementById("scorecard");
    // Get the <span> element that closes the modal
    let span = document.getElementsByClassName("close")[0];
    let btn = document.getElementById("button");
    // When the user clicks the button, open the modal 
    btn.onclick = function() {
            window.location.href = "check.html";
        }
        // When the user clicks the button, open the modal 
        // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
        modal.style.display = "none";
    }

}


function createAudio() {

    let audio = document.createElement('audio');
    let source = document.createElement('source');
    source.src = '/sound/backS.mp3';
    audio.appendChild(source);
    audio.play();
}


// SCENE CFREATED


function createScene() {
    scene = new THREE.Scene();

    scene.background = new THREE.Color('blue');

}

//CAMERA CREATED


function createCamera() {
    camera = new THREE.PerspectiveCamera(70, container.clientWidth / container.clientHeight, 0.01, 300);
    camera.position.set(20, 10, -5);
    camera.rotateY(Math.PI / 2);

}

//SET lIGHT 

function setLight() {

    let keyLight = new THREE.DirectionalLight(new THREE.Color('hsl(30, 100%, 75%)'), 1.0);
    keyLight.position.set(-100, 0, 100);
    let fillLight = new THREE.DirectionalLight(new THREE.Color('hsl(240, 100%, 75%)'), 0.75);
    fillLight.position.set(100, 0, 100);
    let backLight = new THREE.DirectionalLight(0xffffff, 1.0);
    backLight.position.set(100, 0, -100).normalize();
    scene.add(keyLight);
    scene.add(fillLight);
    scene.add(backLight);

    // const light = new THREE.DirectionalLight(0x404040, 5);
    // scene.add(light);

}





//Adding background to the view

function addBackground() {

    //load an image
    let material = new THREE.MeshBasicMaterial({
        map: loader.load("TEXTURE/background.jpg")
    });
    //create a plane
    let geo = new THREE.PlaneGeometry(80, 35);
    //combine an image
    let mesh = new THREE.Mesh(geo, material);
    //set the position
    mesh.position.set(0, 8, 0);
    mesh.rotateY(Math.PI / 2);
    //addthe msh
    scene.add(mesh);
}




function createStar() {
    star_mash1 = new THREE.Group();
    let objLoader = new THREE.OBJLoader();
    objLoader.setPath('/assets/');
    objLoader.load('star.obj', function(object) {
        star_mash1.add(object);
    });
    star_mash1.position.set(5.5, 12, -200)
    star_mash1.rotateX(-Math.PI / 2);
    scene.add(star_mash1);
    star_mash2 = new THREE.Group();
    let objLoader1 = new THREE.OBJLoader();
    objLoader1.setPath('/assets/');
    objLoader1.load('star.obj', function(object) {
        star_mash2.add(object);
    });
    star_mash2.position.set(5.5, 12, -1000)
    star_mash2.rotateX(-Math.PI / 2);
    scene.add(star_mash2);

}

// BALL CREATED


function createBall() {


    let ball_geometry = new THREE.DodecahedronGeometry(0.7, 2);
    let ball_material = new THREE.MeshStandardMaterial({ color: 0x0000ff, shading: THREE.FlatShading })
    ball = new THREE.Mesh(ball_geometry, ball_material);

    ball.rotation.z = 1;
    ball.position.set(5.5, 6.5, 2);
    scene.add(ball);
}
const geometry = new THREE.SphereBufferGeometry(2, 32, 32);





//GRASS TEXTURE LOADER

function createTrack_hurdles() {
    let grass = loader.load('TEXTURE/texture.jpg');
    grasss = loader.load('TEXTURE/grass.jpg');

    for (let d = 0; d < 1000; d++) {
        track_geometry = new THREE.BoxBufferGeometry(10, 0, 12);
        track_material = new THREE.MeshBasicMaterial({
            map: grass
                //color: 0xFF0000
        });
        track_array[d] = new THREE.Mesh(track_geometry, track_material);
        track_array[d].position.set(3.5, 4.5, -12 * p);
        p++;
        scene.add(track_array[d]);

        //hurdles.............
        hurdle_geometry = new THREE.CylinderGeometry(1, 1.5, 7, 32);
        // hurdle_cylinder = new THREE.CylinderGeometry(1, 1.5, 7, 32);
        // BRICK TEXTURE LOADER 
        let brick = loader.load('Texture/texture.jpg');
        hurdle_material = new THREE.MeshBasicMaterial({
            map: brick
                //color: 0x0000FF
        });
        // Acylinder[d] = new THREE.Mesh(hurdle_cylinder, hurdle_material);
        // Acylinder[d].position.set(3.5, 6, -50 * p);
        hurdle_array[d] = new THREE.Mesh(hurdle_geometry, hurdle_material);
        hurdle_array[d].position.set(3.5, 6, -35 * p);

        scene.add(hurdle_array[d]);
        // scene.add(Acylinder[d]);
    }

}


const renderer = new THREE.WebGLRenderer({
    antialias: true
});
renderer.setSize(container.clientWidth, container.clientHeight);
renderer.setPixelRatio(window.devicePixelRatio);
container.appendChild(renderer.domElement);
renderer.render(scene, camera);




//========================**** ANIMATE FUNCTION****==========================
function animate() {
    fn_score(score++);

    // control the hurdle and ball speed //
    speed++;
    speedVector = speed / 10000;
    for (let f = 0; f < 1000; f++) {
        track_array[f].position.z += 0.239 + speedVector;
        hurdle_array[f].position.z += 0.239 + speedVector;
        // Acylinder[f].position.z += 0.299 + speedVector;
    }
    star_mash1.position.z += 0.239;
    star_mash2.position.z += 0.239;
    star_mash1.rotation.z += 0.139;
    star_mash2.rotation.z += 0.139;

    ball.rotation.x -= 0.139;




    hurdle_collision(collide_value);
    star_collision();

    scene.add(ball);
    requestAnimationFrame(animate);
    renderer.render(scene, camera);
}

function star_collision() {
    starcollision1 = new THREE.Box3().setFromObject(ball);
    starcollision2 = new THREE.Box3().setFromObject(star_mash1);
    if (star_mash1.position.z > ball.position.z) {
        starcollision2 = new THREE.Box3().setFromObject(star_mash2);
    }
    collisionst = starcollision1.isIntersectionBox(starcollision2);
    if (collisionst == true) {

        let audiostar = document.createElement('audio');
        let sourcestar = document.createElement('source');
        sourcestar.src = '/sound/star.mp3';
        audiostar.appendChild(sourcestar);
        audiostar.play();
        ball.material.color.set(0xC0C0C0);
        collide_value = false;
        // secondBB = new THREE.Box3().setFromObject(hurdle_array[1]);
        setTimeout(myStopFunction, 30000);

        function myStopFunction() {
            collide_value = true;
            let audiox = document.createElement('audio');
            let sourcex = document.createElement('source');
            sourcex.src = '/sound/oneup.mp3';
            audiox.appendChild(sourcex);
            audiox.play();
            ball.material.color.set(0x0000ff);
        }
    }
}




function hurdle_collision(collide_value) {
    firstBB = new THREE.Box3().setFromObject(ball);
    secondBB = new THREE.Box3().setFromObject(hurdle_array[i]);
    if (hurdle_array[i].position.z > ball.position.z) {
        console.log(hurdle_array[i].position.z);
        i++;
        secondBB = new THREE.Box3().setFromObject(hurdle_array[i]);

    }
    collision = firstBB.isIntersectionBox(secondBB);
    if (collision == true && collide_value == true) {

        ball.material.color.set(0x000000);
        let audioh = document.createElement('audio');
        let sourceh = document.createElement('source');
        sourceh.src = '/sound/out.mp3.mp3';
        audioh.appendChild(sourceh);
        audioh.play();

        modal.style.display = "block";
        score = score - 1;
        final_score.innerHTML += " " + score;
        cancelAnimationFrame();
    }
}

function onWindowResize() {
    camera.aspect = container.clientWidth / container.clientHeight;
    renderer.setSize(container.clientWidth, container.clientHeight);
    camera.updateProjectionMatrix();
}
window.addEventListener('resize', onWindowResize);

document.body.onkeydown = function(e) {
    switch (e.keyCode) {
        case 32:
            bounce();
            break;

    }
}




function fn_score(score) {
    let ty = document.getElementById("score");
    ty.innerHTML = "your score is : " + score;
}

// BOUNCE FUNCTION

function bounce() {
    bouncespeed++;
    bouncespeed = bouncespeed / 500;
    bspeed = bspeed - bouncespeed;
    console.log(bspeed);
    if (jump) {
        console.log("hhhhhhh" + jump)

        let audioj = document.createElement('audio');
        let sourcej = document.createElement('source');
        sourcej.src = '/sound/jump.mp3';
        audioj.appendChild(sourcej);
        audioj.play();
        jump = false;
        TweenLite.to(ball.position, bspeed, {
            ease: CustomEase.create("custom", "M0,0 C0.266,0.412 0.353,0.479 0.52,0.512 0.612,0.53 0.78,0 1,0"),
            y: 20,
            onComplete: () => {
                jump = true;
                console.log(ball);
            }
        });
    }
}
initComplete();
animate();