var audio1 = document.createElement('audio');
var source1 = document.createElement('source');

let span = document.getElementsByClassName("close")[0];

source1.src = '/sound/frontS.mp3';
audio1.appendChild(source1);
audio1.play();

// Get the modal
var modal = document.getElementById("myModal");
modal.style.display = "block";
var playername = document.getElementById("playername");
var EnterName_btn = document.getElementById("button");
var name;
EnterName_btn.onclick = function() {
    name = playername.value;
    console.log(name);
    sessionStorage.setItem("playername1", name);
    modal.style.display = "none";
}


span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}